#!/bin/bash -e
exec env scheme=sql ../007-certsave/run.sh
