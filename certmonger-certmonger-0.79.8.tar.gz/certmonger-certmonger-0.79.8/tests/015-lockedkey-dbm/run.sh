#!/bin/bash -e
exec env scheme=dbm ../015-lockedkey/run.sh
