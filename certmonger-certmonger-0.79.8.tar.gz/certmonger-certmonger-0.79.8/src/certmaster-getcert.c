#include "config.h"
#define FORCE_CA CM_CERTMASTER_CA_NAME
#include "getcert.c"
