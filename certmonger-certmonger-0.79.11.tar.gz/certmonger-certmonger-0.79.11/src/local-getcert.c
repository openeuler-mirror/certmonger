#include "config.h"
#define FORCE_CA CM_LOCAL_CA_NAME
#include "getcert.c"
