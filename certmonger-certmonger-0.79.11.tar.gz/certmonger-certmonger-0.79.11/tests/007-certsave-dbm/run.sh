#!/bin/bash -e
exec env scheme=dbm ../007-certsave/run.sh
