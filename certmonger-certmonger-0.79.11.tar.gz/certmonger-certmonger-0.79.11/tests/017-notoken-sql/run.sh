#!/bin/bash -e
exec env scheme=sql ../017-notoken/run.sh
