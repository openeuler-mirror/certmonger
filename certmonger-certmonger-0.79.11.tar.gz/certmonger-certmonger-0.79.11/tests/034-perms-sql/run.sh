#!/bin/bash -e
exec env scheme=sql: ../034-perms/run.sh
